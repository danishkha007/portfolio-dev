<?php 

define('DB_HOST','localhost');
define('DB_NAME','danish');
define('DB_USER','root');
define('DB_PASS','');
define('WWW_ROOT','http://localhost/danish/');


//SMTP
// define("M_HOST","smtp.gmail.com");
// define("M_USERNAME","aktureference@gmail.com");
// define("M_PASSWORD","ljvxcyyudtftomys");
// define("M_SMTPSECURE","tls");
// define("M_PORT","587");