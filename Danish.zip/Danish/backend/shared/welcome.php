<section class="container welcome">
    <div class="inner-ctn welcome-ctn">
        <div class="intro-left">
            <div>
                <h1>Hey there, I am <span>Danish Khan</span></h1>
            </div>
            <div>
                <p>Currently, I am working in Tata Consultancy Services as Assistant System Engineer</p>
            </div>
            <div>
                <button class="btn">Download CV</button>
            </div>
        </div>
        <div class="intro-right">
            <div class="img-mine">
                <!-- <img src="<?php echo url_for('frontend\assets\images\myImage-1.jpg') ?>"> -->
            </div>
        </div>
    </div>
</section>