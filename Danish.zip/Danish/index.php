<?php 
require "backend/init.php";
require "backend/shared/header.php";
require "backend/shared/welcome.php";
require "backend/shared/projects.php";
?>
